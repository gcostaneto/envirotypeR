#' Genome to Fields (G2F) GxE panel (2014-2017)
#'
#'@description  Genomes to fields (G2F) is a multi-institutional, public collaborative to develop information and tools that support the
#'translation of maize (Zea mays L.) genomic information into relevant phenotypes for the benefit of growers, consumers,
#'and society. Building on existing maize genome sequence resources, the project focuses on developing approaches to improve phenomic predictability and facilitate
#' the development and deployment of tools and resources that help address fundamental problems of sustainable agricultural productivity.
#' Specific projects within G2F involve collaboration from research fields such as genetics, genomics, plant physiology, agronomy, climatology and crop modeling,
#' computational sciences, statistics, and engineering. See https://bmcresnotes.biomedcentral.com/articles/10.1186/s13104-020-4922-8.
#'
#' Here we used the geographic coordinates from 93 environments (diverse locations across 4 years)
#'
#'
#'@format A data.frame containing environmental identifications (env), geographic coordinates (lat, lon) and the time window (start, end) given in YYYY-MM-DD.

#'@docType data
#'
#'@usage data(G2F_2014_17)
#'
#'@examples
#'\dontrun{
#' require(EnvRtype)
#' data(G2F_2014_17)
#'
#' data = G2F_2014_17
#' env   = data$env
#' lon   = data$lon
#' lat   = data$lat
#' env   = data$env
#' start = data$start
#' end = data$end
#' country = rep('USA1',length(lon))
#'
#'
#' env.data =
#'   EnvRtype::get_weather(env.id = env,
#'                         lat = lat,
#'                         lon = lon,
#'                         start.day = start,
#'                         end.day = end,
#'                         country = country,
#'                         parallel = TRUE)
#'
#'head(env.data)
#'}
#' @format data.frame file

"G2F_2014_17"
