# General Model

$$ y=1 \mu+Z_{E} \beta+\sum_{s=1}^{k} g_{s}+\sum_{s=1}^{k} g E_{s}+\sum_{r=1}^{l} W_{r}+\sum_{s=1}^{k} \sum_{r=1}^{l} g W_{s r}+\varepsilon $$

<img align="left" src="https://cdn.mathpix.com/snip/images/66iktc_OWFCFVgWZng_XT8hvNsFKYLFEVrYipE5O9TU.original.fullsize.png" width="100%" height="100%">

